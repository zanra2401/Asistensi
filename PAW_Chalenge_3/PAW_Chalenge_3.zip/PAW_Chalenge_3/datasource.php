<?php

$product = [
    [
        "nama_produk" => "Televisi LED 32 inci",
        "kategori" => "Elektronik",
        "stok" => 5,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Laptop Gaming Ryzen 5",
        "kategori" => "Elektronik",
        "stok" => 3,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Headphone Bluetooth",
        "kategori" => "Elektronik",
        "stok" => 8,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Kamera DSLR Canon EOS 200D",
        "kategori" => "Elektronik",
        "stok" => 4,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Smartwatch FitPro X10",
        "kategori" => "Elektronik",
        "stok" => 9,
        "gambar" => "https://lipsum.app/300x300"
    ],

    [
        "nama_produk" => "Kemeja Pria Lengan Panjang",
        "kategori" => "Fashion",
        "stok" => 12,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Sepatu Olahraga Wanita",
        "kategori" => "Fashion",
        "stok" => 10,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Jaket Hoodie Oversize",
        "kategori" => "Fashion",
        "stok" => 6,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Celana Jeans Slim Fit",
        "kategori" => "Fashion",
        "stok" => 15,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Topi Baseball Polos",
        "kategori" => "Fashion",
        "stok" => 20,
        "gambar" => "https://lipsum.app/300x300"
    ],

    [
        "nama_produk" => "Beras Premium 5 Kg",
        "kategori" => "Sembako",
        "stok" => 25,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Minyak Goreng 1 Liter",
        "kategori" => "Sembako",
        "stok" => 30,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Gula Pasir 2 Kg",
        "kategori" => "Sembako",
        "stok" => 18,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Telur Ayam 1 Kg",
        "kategori" => "Sembako",
        "stok" => 12,
        "gambar" => "https://lipsum.app/300x300"
    ],

    [
        "nama_produk" => "Kursi Kantor Ergonomis",
        "kategori" => "Perabotan",
        "stok" => 7,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Meja Belajar Lipat",
        "kategori" => "Perabotan",
        "stok" => 10,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Panci Stainless Steel",
        "kategori" => "Perabotan",
        "stok" => 14,
        "gambar" => "https://lipsum.app/300x300"
    ],

    [
        "nama_produk" => "Raket Badminton Yonex",
        "kategori" => "Olahraga",
        "stok" => 6,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Bola Sepak Adidas",
        "kategori" => "Olahraga",
        "stok" => 8,
        "gambar" => "https://lipsum.app/300x300"
    ],
    [
        "nama_produk" => "Nasi Kotak Ayam Geprek",
        "kategori" => "Makanan",
        "stok" => 20,
        "gambar" => "https://lipsum.app/300x300"
    ]
];
