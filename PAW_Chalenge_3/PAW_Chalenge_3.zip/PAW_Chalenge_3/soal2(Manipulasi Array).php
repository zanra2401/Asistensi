<?php
/**
 * Soal 2 (Manipulasi dan Penyajian)
 * Tujuan: Praktikan memahami bagaimana memanipulasi 
 * array dan menyajikanya ke dalam html dengan php
 */
require_once __DIR__ . "/datasource.php";
?>